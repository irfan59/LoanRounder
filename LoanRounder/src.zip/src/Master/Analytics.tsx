import {View, Text, Dimensions} from 'react-native';
import React, {useState} from 'react';
import {SidebarMenuData} from '../Components/SidebarMenu';
import SideMenu from 'react-native-side-menu';
const Analytics: React.FC<any> = ({navigation}) => {
  let windowHeight = Dimensions.get('window').height;
  let windowWidth = Dimensions.get('window').width;

  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <SideMenu
      menu={<SidebarMenuData navigation={navigation} />}
      isOpen={isOpen}
      onChange={(isOpen: any) => setIsOpen(isOpen)}
      openMenuOffset={windowWidth / 1.2}>
      <View>
        <Text>Analytics</Text>
      </View>
    </SideMenu>
  );
};

export default Analytics;
