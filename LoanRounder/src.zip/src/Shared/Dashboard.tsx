import {View, Text, Image, Dimensions, TouchableOpacity} from 'react-native';
import React, {useState} from 'react';
import Footer from './Footer';
import {CommonStyles} from '../Css/CommonCss';
import SideMenu from 'react-native-side-menu';
import {styles} from '../Css/Shared/DashboardCss';
import {SidebarMenuData} from '../Components/SidebarMenu';
import Header from '../Components/Header';
const Dashboard: React.FC<any> = ({navigation}) => {
  let windowHeight = Dimensions.get('window').height;
  let windowWidth = Dimensions.get('window').width;

  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <>
      <Header />
      <Footer navigation={navigation} />
    </>
  );
};

export default Dashboard;
