import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  heading: {
    fontSize: 18,
    color: '#000',
    fontWeight: '800',
  },
  maintextinput: {},
  textinput: {},
});
